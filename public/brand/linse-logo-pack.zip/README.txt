Linse logo pack (Linsetech Ltd)

Files: the LS mark alone, and the horizontal and stacked lockups, each as SVG (vector) and PNG (2000 px wide, transparent),
in four colours: offwhite #F3F3F3 (on night), ink #0B1411 (on light), night #020A07 (on green), green #22C55E (on night).

Clear space: the width of the L stem (about a quarter of the mark's height) on every side.
Minimum size: mark 16 px tall; horizontal lockup 72 px wide.
Do not stretch, rotate, outline, recolour outside the palette or add effects.

Typeface: Archivo (headlines and body), Archivo Narrow (labels), both free on Google Fonts.
Brand guidelines: https://linsetech.com/brand
